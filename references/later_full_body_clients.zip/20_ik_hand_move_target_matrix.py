#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Pinocchio 灵巧手 sensor_2 ground 目标矩阵 IK + 机械臂位置运动 demo。

本 demo 参考 19_P_ik_move_target_matrix.py 的格式：
1. 程序顶部输入 TARGET_GROUND_HAND_SENSOR，含义为 T_ground_<finger>_sensor_2。
2. 使用灵巧手 FK 计算 T_tcp_<finger>_sensor_2。
3. 反推出手臂 TCP 目标：T_ground_tcp = T_ground_sensor_2 @ inv(T_tcp_sensor_2)。
4. 调用 /ik/full_body_ik 服务做 Pinocchio 全身逆解。
5. 程序顶部 LEG_ENABLE=True 时，让腿部/body 参与 IK 搜索。
6. 本 demo 永远不会下发腿部真实运动指令，只会打印腿部逆解结果。
7. 逆解成功后，取对应手臂 7 个关节角，并可通过 --execute 下发到机械臂。

默认只计算和打印结果；加入 --execute 后才真正运动。
"""

from __future__ import annotations

import argparse
import math
import sys
import time
from typing import Optional

import numpy as np
import rclpy

from arm_ros2_common import MarvinServiceClient, arm_index, command, finish
from marvin_interfaces.msg import RobotFrames
from sensor_msgs.msg import JointState
from marvin_interfaces.srv import (
    ArmClearErr,
    PinocchioFullBodyIK,
    SetArmState,
    SetArmVelAcc,
    SetJointCmdPos,
)

MARVIN_ROBOT_PY_DIR = "/home/user/jibot_ros2_opensource/30_ros_ws/src/drivers/marvin_robot/marvin_robot"
if MARVIN_ROBOT_PY_DIR not in sys.path:
    sys.path.insert(0, MARVIN_ROBOT_PY_DIR)

from jibot_kine import RobotHand  # noqa: E402


DEFAULT_ARM_ID = "A"  # A=左臂，对应 L_arm；B=右臂，对应 R_arm。

PRE_MOVE_LEFT_ARM_ENABLE = True
PRE_MOVE_LEFT_ARM_JOINTS_DEG = [30.9562, -41.2021, -36.4856, -49.9895, 20.9347, -7.3186, -18.0772]
PRE_MOVE_LEFT_ARM_HOLD_SEC = 0.5
ARM_GROUND_FRAMES_TOPIC = "/frame/arm_ground_frames"
FULL_BODY_IK_SERVICE = "/ik/full_body_ik"
BODY_JOINT_STATES_TOPIC = "/joint_states"

# 仅在身体驱动无法启动、且腰/腿物理位置确认在零位时使用。
# head 两个关节一并提供 0，是为了构造完整的 body JointState；它们不参与手臂 ground TCP 换算。
ZERO_BODY_JOINT_NAMES = (
    "head_pitch",
    "head_yaw",
    "waist_joint",
    "leg_joint_3",
    "leg_joint_2",
    "leg_joint_1",
)
ZERO_BODY_PUBLISH_PERIOD_SEC = 0.05

# 目标矩阵接口：T_ground_<finger>_sensor_2，即灵巧手指定手指 sensor_2 相对于底盘/ground 坐标系的目标位姿。
# 左上角 3x3 是旋转矩阵，最后一列前三个数是位置 XYZ，单位 m。
# 注意：LEG_ENABLE 只让腿部参与 IK 计算，本 demo 仍不会下发腿部真实运动指令。
FINGER_NAME = "index"  # 当前默认使用食指 sensor_2；可选 thumb/index/middle/ring/little。
HAND_COMMANDS = 1000  # 灵巧手 FK 使用的手指命令，0-1000；可写成数字或 {"index": 1000} 这种 dict。

TARGET_GROUND_HAND_SENSOR = np.array([
    [-0.18246619,  0.98193100,  0.05017566,  0.757606],
    [-0.91100494, -0.18804125,  0.36702927,  0.365615],
    [ 0.36983251,  0.02126016,  0.92885517,  1.1361435],
    [ 0.0,         0.0,         0.0,         1.0       ],
], dtype=float)

LEG_ENABLE = True
VELOCITY_PERCENT = 10
ACCELERATION_PERCENT = 10
WAIT_AFTER_COMMAND_SEC = 3.0
ARRIVE_TOLERANCE_DEG = 1.0
CHECK_PERIOD_SEC = 0.2
STATE_TIMEOUT_SEC = 5.0
TARGET_TIMEOUT_SEC = 30.0
HOLD_AFTER_ARRIVE_SEC = 0.5
SERVICE_TIMEOUT_SEC = 10.0

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="strict")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="strict")


class PinocchioGroundIkMoveClient(MarvinServiceClient):
    """调用 Pinocchio IK 服务和机械臂运动服务的客户端。"""

    def __init__(self, arm_id: str, assume_zero_body: bool = False):
        super().__init__("pinocchio_hand_ik_move_demo")
        self.arm_id = arm_id
        self.full_body_ik_cli = self.create_client(PinocchioFullBodyIK, FULL_BODY_IK_SERVICE)
        self.clear_cli = self.create_client(ArmClearErr, "/arm/clear_arm_error")
        self.state_cli = self.create_client(SetArmState, "/arm/set_arm_state")
        self.vel_cli = self.create_client(SetArmVelAcc, "/arm/set_arm_vel_acc")
        self.position_cli = self.create_client(SetJointCmdPos, "/arm/set_joint_cmd_pos")
        self.latest_ground_frames: Optional[RobotFrames] = None
        self.create_subscription(RobotFrames, ARM_GROUND_FRAMES_TOPIC, self._ground_frames_callback, 10)
        self._zero_body_publisher = None
        self._zero_body_timer = None
        self._zero_body_conflict = ""
        if assume_zero_body:
            self._start_zero_body_publisher()

    def _ground_frames_callback(self, message: RobotFrames) -> None:
        self.latest_ground_frames = message

    def _external_body_publishers(self):
        return [
            info
            for info in self.get_publishers_info_by_topic(BODY_JOINT_STATES_TOPIC)
            if not (info.node_name == self.get_name() and info.node_namespace == self.get_namespace())
        ]

    def _start_zero_body_publisher(self) -> None:
        # Allow DDS discovery to see an already-running real body-state publisher.
        discovery_deadline = time.monotonic() + 0.5
        while time.monotonic() < discovery_deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
        external = self._external_body_publishers()
        if external:
            names = [f"{info.node_namespace}/{info.node_name}" for info in external]
            raise RuntimeError(
                f"拒绝启用 --assume-zero-body：{BODY_JOINT_STATES_TOPIC} 已有发布者 {names}"
            )
        self._zero_body_publisher = self.create_publisher(JointState, BODY_JOINT_STATES_TOPIC, 10)
        self._zero_body_timer = self.create_timer(
            ZERO_BODY_PUBLISH_PERIOD_SEC,
            self._publish_zero_body_joint_state,
        )
        self._publish_zero_body_joint_state()
        self.get_logger().warning(
            "ZERO BODY ASSUMPTION enabled: publishing waist/leg joints as 0 deg; "
            "this does not enable or move body actuators"
        )

    def _publish_zero_body_joint_state(self) -> None:
        external = self._external_body_publishers()
        if external:
            names = [f"{info.node_namespace}/{info.node_name}" for info in external]
            self._zero_body_conflict = (
                f"检测到真实 {BODY_JOINT_STATES_TOPIC} 发布者 {names}，已停止发布假定零位"
            )
            if self._zero_body_timer is not None:
                self._zero_body_timer.cancel()
            self.get_logger().error(self._zero_body_conflict)
            return
        message = JointState()
        message.header.stamp = self.get_clock().now().to_msg()
        message.name = list(ZERO_BODY_JOINT_NAMES)
        message.position = [0.0] * len(ZERO_BODY_JOINT_NAMES)
        self._zero_body_publisher.publish(message)

    def ensure_zero_body_source_safe(self) -> None:
        if self._zero_body_conflict:
            raise RuntimeError(self._zero_body_conflict)


def parse_args():
    parser = argparse.ArgumentParser(description="Pinocchio 灵巧手 sensor_2 ground 目标矩阵 IK + 机械臂位置运动 demo")
    parser.add_argument("--arm", default=DEFAULT_ARM_ID, choices=["A", "B", "a", "b"], help="选择机械臂 A/B，A=左臂，B=右臂")
    parser.add_argument("--mat4x4", type=float, nargs=16, help="目标 T_ground_<finger>_sensor_2，16 个数，按行优先排列，位置单位 m")
    parser.add_argument(
        "--delta-xyz",
        type=float,
        nargs=3,
        metavar=("DX", "DY", "DZ"),
        help="以当前 sensor_2 为起点增加 ground XYZ 位移(m)，并保持当前姿态；不能与 --mat4x4 同用",
    )
    parser.add_argument("--frame-timeout", type=float, default=5.0, help="等待 /frame/arm_ground_frames 的超时时间，单位秒")
    parser.add_argument("--service-timeout", type=float, default=SERVICE_TIMEOUT_SEC, help="等待 /ik/full_body_ik 服务上线的超时时间，单位秒")
    parser.add_argument("--target-timeout", type=float, default=TARGET_TIMEOUT_SEC, help="等待机械臂到达目标关节角的超时时间，单位秒")
    parser.add_argument("--arm-max-iterations", type=int, default=0, help="Pinocchio 手臂 IK 最大迭代次数；0 表示使用服务默认值")
    parser.add_argument("--keep-enabled", action="store_true", help="运动结束后保持位置模式，不自动下使能")
    parser.add_argument("--allow-state-mismatch", action="store_true", help="即使反馈状态没有切到位置模式也继续下发目标，不推荐")
    parser.add_argument("--skip-pre-move", action="store_true", help="跳过代码内置的左臂预备关节动作")
    parser.add_argument(
        "--assume-zero-body",
        action="store_true",
        help="当 /joint_states 无发布者时，发布腰/腿固定0度的计算状态；不使能、不控制腿部",
    )
    parser.add_argument(
        "--confirm-zero-body-execute",
        action="store_true",
        help="确认物理腰/腿确实固定在零位，允许 --assume-zero-body 与 --execute 同用",
    )
    parser.add_argument("--execute", action="store_true", help="真正下发运动指令；未设置时只计算 IK")
    return parser.parse_known_args()


def arm_name_from_id(arm_id: str) -> str:
    return "L_arm" if arm_id.upper() == "A" else "R_arm"


def arm_label(arm_id: str) -> str:
    return "左臂 Arm A" if arm_id.upper() == "A" else "右臂 Arm B"


def hand_name_from_arm_id(arm_id: str) -> str:
    return "L_hand" if arm_id.upper() == "A" else "R_hand"


def get_tcp_sensor_transform(hand: RobotHand) -> np.ndarray:
    """返回 T_tcp_<finger>_sensor_2。"""
    if FINGER_NAME not in RobotHand.FINGER_NAMES:
        raise ValueError(f"FINGER_NAME 必须是 {list(RobotHand.FINGER_NAMES)} 之一，当前是 {FINGER_NAME!r}")
    t_tcp_hand_base = RobotHand.get_tcp_hand_base_transform()
    t_hand_base_sensor = hand.get_hand_base_sensor_transform(
        FINGER_NAME,
        hand_commands=HAND_COMMANDS,
    )
    return t_tcp_hand_base @ t_hand_base_sensor


def hand_sensor_target_to_arm_tcp_target(target_ground_sensor: np.ndarray, t_tcp_sensor: np.ndarray) -> np.ndarray:
    """由 T_ground_<finger>_sensor_2 反推出 T_ground_tcp。"""
    return target_ground_sensor @ np.linalg.inv(t_tcp_sensor)


def print_matrix(name: str, matrix: np.ndarray | None) -> None:
    print(f"\n{name}:")
    if matrix is None:
        print("None")
    else:
        print(np.array2string(matrix, precision=8, suppress_small=True))


def matrix_to_rpy_deg(rotation: np.ndarray) -> tuple[float, float, float]:
    """旋转矩阵转 RPY 角度，R = Rz(yaw) @ Ry(pitch) @ Rx(roll)。"""
    sy = math.sqrt(rotation[0, 0] * rotation[0, 0] + rotation[1, 0] * rotation[1, 0])
    singular = sy < 1e-9
    if not singular:
        roll = math.atan2(rotation[2, 1], rotation[2, 2])
        pitch = math.atan2(-rotation[2, 0], sy)
        yaw = math.atan2(rotation[1, 0], rotation[0, 0])
    else:
        roll = math.atan2(-rotation[1, 2], rotation[1, 1])
        pitch = math.atan2(-rotation[2, 0], sy)
        yaw = 0.0
    return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)


def print_pose_rpy(label: str, matrix: np.ndarray) -> None:
    roll_deg, pitch_deg, yaw_deg = matrix_to_rpy_deg(matrix[:3, :3])
    print(
        f"{label} RPY(deg): "
        f"roll={roll_deg:.7f}, pitch={pitch_deg:.7f}, yaw={yaw_deg:.7f}"
    )




def select_target_matrix(options, current_ground_sensor: np.ndarray | None) -> tuple[np.ndarray, str]:
    if options.mat4x4 is not None and options.delta_xyz is not None:
        raise ValueError("--mat4x4 与 --delta-xyz 不能同时使用")
    if options.mat4x4 is not None:
        return np.array(options.mat4x4, dtype=float).reshape((4, 4)), "命令行 --mat4x4 目标矩阵"
    if options.delta_xyz is not None:
        if current_ground_sensor is None:
            raise RuntimeError("--delta-xyz 需要有效的当前 sensor_2 ground 位姿")
        target = current_ground_sensor.copy()
        target[:3, 3] += np.asarray(options.delta_xyz, dtype=float)
        return target, f"当前 sensor_2 增加 ground 位移 {list(options.delta_xyz)} m"
    return TARGET_GROUND_HAND_SENSOR.copy(), "程序 TARGET_GROUND_HAND_SENSOR 目标矩阵"

def read_current_ground_frame(node: PinocchioGroundIkMoveClient, timeout_sec: float) -> tuple[np.ndarray | None, list[float]]:
    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
        node.ensure_zero_body_source_safe()
        message = node.latest_ground_frames
        if message is None or not message.success:
            continue

        if node.arm_id == "A":
            matrix_data = message.ground_left_tcp
            joints = message.left_arm_joints_deg
        else:
            matrix_data = message.ground_right_tcp
            joints = message.right_arm_joints_deg

        current_tcp = None
        if len(matrix_data) == 16:
            current_tcp = np.array(matrix_data, dtype=float).reshape((4, 4))
        return current_tcp, [float(value) for value in joints]

    return None, []


def print_target_delta(current_matrix: np.ndarray, target_matrix: np.ndarray) -> None:
    delta_xyz = target_matrix[:3, 3] - current_matrix[:3, 3]
    relative_matrix = np.linalg.inv(current_matrix) @ target_matrix
    relative_rpy = matrix_to_rpy_deg(relative_matrix[:3, :3])
    print(
        "当前到目标的 ground 位移 XYZ(m): "
        f"({delta_xyz[0]:.7f}, {delta_xyz[1]:.7f}, {delta_xyz[2]:.7f})"
    )
    print(
        "当前局部坐标系下的相对目标: "
        f"dx={relative_matrix[0, 3]:.7f} m, "
        f"dy={relative_matrix[1, 3]:.7f} m, "
        f"dz={relative_matrix[2, 3]:.7f} m, "
        f"roll={relative_rpy[0]:.7f} deg, "
        f"pitch={relative_rpy[1]:.7f} deg, "
        f"yaw={relative_rpy[2]:.7f} deg"
    )


def flatten_matrix(matrix: np.ndarray) -> list[float]:
    return [float(value) for row in matrix for value in row]


def matrix_from_response(values) -> np.ndarray | None:
    data = [float(value) for value in values]
    if len(data) != 16:
        return None
    return np.array(data, dtype=float).reshape((4, 4))


def matrix_error(matrix_a: np.ndarray | None, matrix_b: np.ndarray | None) -> float:
    if matrix_a is None or matrix_b is None:
        return float("inf")
    return float(np.max(np.abs(np.asarray(matrix_a, dtype=float) - np.asarray(matrix_b, dtype=float))))


def call_pinocchio_ik(
    node: PinocchioGroundIkMoveClient,
    arm_name: str,
    target_ground_tcp: np.ndarray,
    arm_max_iterations: int,
    leg_enable: bool,
    service_timeout_sec: float,
) -> PinocchioFullBodyIK.Response:
    node.ensure_zero_body_source_safe()
    start_time = time.monotonic()
    while not node.full_body_ik_cli.wait_for_service(timeout_sec=1.0):
        node.get_logger().info(f"Waiting for {node.full_body_ik_cli.srv_name} ...")
        if time.monotonic() - start_time > service_timeout_sec:
            raise RuntimeError(
                f"{node.full_body_ik_cli.srv_name} 服务未上线。请先在另一个终端启动："
                "ros2 run marvin_robot pinocchio_ik_service_node"
            )

    request = PinocchioFullBodyIK.Request()
    request.tcp_name = arm_name
    request.target_ground_matrix = flatten_matrix(target_ground_tcp)
    request.leg_enable = bool(leg_enable)
    request.normalize_rotation = False  # Use solver.normalize_rotation from full_body_ik_config.yaml.
    request.arm_max_iterations = int(arm_max_iterations)
    request.leg_max_iterations = 0  # Use solver.leg_max_iterations from full_body_ik_config.yaml.

    future = node.full_body_ik_cli.call_async(request)
    rclpy.spin_until_future_complete(node, future)
    if future.exception() is not None:
        raise RuntimeError(f"{node.full_body_ik_cli.srv_name} raised: {future.exception()}")
    return future.result()


def select_response_arm_joints(response: PinocchioFullBodyIK.Response, arm_id: str) -> list[float]:
    joints = response.left_arm_joints_deg if arm_id.upper() == "A" else response.right_arm_joints_deg
    return [float(value) for value in joints]


def read_arm_feedback(node: PinocchioGroundIkMoveClient, arm_id: str) -> dict:
    data = node.robot_data()
    index = arm_index(arm_id)
    if len(data.outputs) <= index or len(data.states) <= index or len(data.inputs) <= index:
        raise RuntimeError(f"robot_data does not contain arm {arm_id}")

    state = data.states[index]
    output = data.outputs[index]
    input_data = data.inputs[index]
    return {
        "state": int(state.cur_state),
        "cmd_state": int(state.cmd_state),
        "err_code": int(state.err_code),
        "joints": [float(value) for value in output.fb_joint_pos],
        "joint_cmd_pos": [float(value) for value in input_data.joint_cmd_pos],
    }


def log_arm_feedback(node: PinocchioGroundIkMoveClient, arm_id: str, label: str) -> dict:
    feedback = read_arm_feedback(node, arm_id)
    node.get_logger().info(
        f"{label} Arm {arm_id}: state={feedback['state']}, cmd_state={feedback['cmd_state']}, "
        f"err={feedback['err_code']}, fb={[round(v, 3) for v in feedback['joints']]}, "
        f"cmd={[round(v, 3) for v in feedback['joint_cmd_pos']]}"
    )
    return feedback


def wait_for_arm_state(node: PinocchioGroundIkMoveClient, arm_id: str, expected_state: int, timeout_sec: float) -> None:
    start_time = time.monotonic()
    last = None
    while time.monotonic() - start_time <= timeout_sec:
        feedback = read_arm_feedback(node, arm_id)
        last = feedback
        if feedback["err_code"] != 0:
            raise RuntimeError(
                f"Arm {arm_id} reports error while waiting state {expected_state}: "
                f"state={feedback['state']}, cmd_state={feedback['cmd_state']}, err={feedback['err_code']}"
            )
        if feedback["state"] == expected_state:
            return
        time.sleep(CHECK_PERIOD_SEC)

    raise RuntimeError(
        f"Arm {arm_id} did not enter state {expected_state} within {timeout_sec}s. "
        f"Last feedback: state={last['state'] if last else 'unknown'}, "
        f"cmd_state={last['cmd_state'] if last else 'unknown'}, "
        f"err={last['err_code'] if last else 'unknown'}"
    )


def max_abs_error(actual: list[float], target: list[float]) -> float:
    return max(abs(float(a) - float(t)) for a, t in zip(actual, target))


def wait_until_arrived(node: PinocchioGroundIkMoveClient, arm_id: str, target_joints: list[float], timeout_sec: float) -> None:
    start_time = time.monotonic()
    last_log_time = -1.0
    while True:
        feedback = read_arm_feedback(node, arm_id)
        if feedback["err_code"] != 0:
            raise RuntimeError(
                f"Arm {arm_id} reports error while moving: "
                f"state={feedback['state']}, cmd_state={feedback['cmd_state']}, err={feedback['err_code']}"
            )
        if feedback["state"] != 1:
            raise RuntimeError(
                f"Arm {arm_id} left position mode while moving: "
                f"state={feedback['state']}, cmd_state={feedback['cmd_state']}, err={feedback['err_code']}"
            )

        error = max_abs_error(feedback["joints"], target_joints)
        if error <= ARRIVE_TOLERANCE_DEG:
            node.get_logger().info(f"Arm {arm_id} arrived: max error={error:.3f} deg")
            time.sleep(HOLD_AFTER_ARRIVE_SEC)
            return

        elapsed = time.monotonic() - start_time
        if elapsed > timeout_sec:
            raise RuntimeError(
                f"Arm {arm_id} timeout after {timeout_sec}s: max error={error:.3f} deg, "
                f"fb={[round(v, 3) for v in feedback['joints']]}, "
                f"cmd={[round(v, 3) for v in feedback['joint_cmd_pos']]}, "
                f"target={[round(v, 3) for v in target_joints]}"
            )

        if elapsed - last_log_time >= 1.0:
            node.get_logger().info(
                f"Waiting Arm {arm_id}: max error={error:.3f} deg, "
                f"fb={[round(v, 3) for v in feedback['joints']]}"
            )
            last_log_time = elapsed
        time.sleep(CHECK_PERIOD_SEC)



def prepare_left_arm_before_ik(node, arm_id: str, options, execute_motion: bool, enabled: bool) -> bool:
    if not PRE_MOVE_LEFT_ARM_ENABLE:
        return enabled
    if arm_id.upper() != "A":
        node.get_logger().info("Pre-move skipped: configured only for left arm A")
        return enabled
    if options.skip_pre_move:
        node.get_logger().info("Pre-move skipped by --skip-pre-move")
        return enabled
    if not execute_motion:
        node.get_logger().warning("Pre-move skipped in dry run. Add --execute to move left arm before IK.")
        return enabled

    node.connect_robot()
    log_arm_feedback(node, arm_id, "Before pre-move configure")

    clear_response = command(node, node.clear_cli, ArmClearErr, arm_id=arm_id)
    node.get_logger().info(f"Arm {arm_id} pre-move clear response: {clear_response.message}")
    vel_response = command(node, node.vel_cli, SetArmVelAcc, arm_id=arm_id, vel=VELOCITY_PERCENT, acc=ACCELERATION_PERCENT)
    node.get_logger().info(f"Arm {arm_id} pre-move vel/acc response: {vel_response.message}")
    state_response = command(node, node.state_cli, SetArmState, arm_id=arm_id, state=1)
    node.get_logger().info(f"Arm {arm_id} pre-move set state response: {state_response.message}")
    if not options.allow_state_mismatch:
        wait_for_arm_state(node, arm_id, expected_state=1, timeout_sec=STATE_TIMEOUT_SEC)
        node.get_logger().info(f"Arm {arm_id} is in position mode for pre-move")

    command_response = command(node, node.position_cli, SetJointCmdPos, arm_id=arm_id, joints=PRE_MOVE_LEFT_ARM_JOINTS_DEG)
    node.get_logger().info(f"Arm {arm_id} pre-move target response: {command_response.message}")
    node.get_logger().info(f"Pre-move left arm target joints sent: {[round(v, 4) for v in PRE_MOVE_LEFT_ARM_JOINTS_DEG]}")
    wait_until_arrived(node, arm_id, PRE_MOVE_LEFT_ARM_JOINTS_DEG, timeout_sec=options.target_timeout)
    time.sleep(PRE_MOVE_LEFT_ARM_HOLD_SEC)
    return True

def main() -> None:
    np.set_printoptions(suppress=True, precision=8, floatmode="fixed")
    options, ros_args = parse_args()
    arm_id = options.arm.upper()
    arm_name = arm_name_from_id(arm_id)
    execute_motion = bool(options.execute)
    if execute_motion and LEG_ENABLE:
        raise RuntimeError(
            "拒绝执行：LEG_ENABLE=True 时本 demo 只计算全身逆解，不下发腿部运动。"
            "请移除 --execute；若要真实执行全身解，必须使用同时控制腿部与手臂的专用程序。"
        )
    if options.confirm_zero_body_execute and not options.assume_zero_body:
        raise ValueError("--confirm-zero-body-execute 只能与 --assume-zero-body 一起使用")
    if execute_motion and options.assume_zero_body and not options.confirm_zero_body_execute:
        raise RuntimeError(
            "拒绝执行：使用 --assume-zero-body 下发机械臂运动时，必须额外提供 "
            "--confirm-zero-body-execute，确认物理腰/腿确实固定在零位"
        )
    if execute_motion and options.mat4x4 is None and options.delta_xyz is None:
        raise RuntimeError("拒绝执行代码内置目标；请显式提供 --delta-xyz 或 --mat4x4")
    rclpy.init(args=[sys.argv[0], *ros_args])
    node = PinocchioGroundIkMoveClient(arm_id, assume_zero_body=options.assume_zero_body)
    enabled = False

    try:
        enabled = prepare_left_arm_before_ik(node, arm_id, options, execute_motion, enabled)
        hand_name = hand_name_from_arm_id(arm_id)
        selected_hand = RobotHand(hand_name)
        t_tcp_sensor = get_tcp_sensor_transform(selected_hand)

        current_ground_tcp, current_joints = read_current_ground_frame(node, options.frame_timeout)
        current_ground_sensor = current_ground_tcp @ t_tcp_sensor if current_ground_tcp is not None else None
        target_ground_sensor, target_source = select_target_matrix(options, current_ground_sensor)
        target_ground_tcp = hand_sensor_target_to_arm_tcp_target(target_ground_sensor, t_tcp_sensor)

        print("Jibot Pinocchio IK 运动 Demo 20：输入灵巧手 sensor_2 ground 目标矩阵，只控制手臂")
        print(f"机械臂: {arm_label(arm_id)}，Pinocchio tcp_name={arm_name}")
        print(f"灵巧手: {hand_name}，目标手指: {FINGER_NAME}，目标传感器: sensor_2")
        print(f"灵巧手 FK 命令: {HAND_COMMANDS}")
        print("目标矩阵含义: T_ground_<finger>_sensor_2，即手指 sensor_2 相对于底盘/ground 的位姿")
        if LEG_ENABLE:
            print("腿部逆解: 开启。服务请求 leg_enable=True，腿部/body 参与 IK 搜索")
        else:
            print("腿部逆解: 关闭。服务请求 leg_enable=False，只用当前腿部/body 位姿做坐标换算")
        if options.assume_zero_body:
            print("身体状态来源: 假定腰/腿固定为 0 度（仅发布计算状态，不使能、不控制腿部）")
        print(f"目标矩阵来源: {target_source}")
        print("目标旋转矩阵自动归一化: 使用服务端 full_body_ik_config.yaml 配置")
        if current_joints:
            print(f"当前机械臂反馈关节角(deg): {[round(v, 6) for v in current_joints]}")
        if current_ground_tcp is not None:
            print_matrix("当前 /frame/arm_ground_frames 读取到的 T_ground_tcp", current_ground_tcp)
            print_pose_rpy("Current ground TCP", current_ground_tcp)
        if current_ground_sensor is not None:
            print_matrix(f"当前 {hand_name} {FINGER_NAME} T_ground_{FINGER_NAME}_sensor_2", current_ground_sensor)
            print_pose_rpy(f"Current ground {FINGER_NAME} sensor_2", current_ground_sensor)
            print_target_delta(current_ground_sensor, target_ground_sensor)

        print_matrix("输入目标 TARGET_GROUND_HAND_SENSOR", target_ground_sensor)
        print(
            f"目标 {FINGER_NAME} sensor_2 ground 位置 XYZ(m): "
            f"({target_ground_sensor[0, 3]:.7f}, {target_ground_sensor[1, 3]:.7f}, {target_ground_sensor[2, 3]:.7f})"
        )
        print_pose_rpy(f"Target ground {FINGER_NAME} sensor_2", target_ground_sensor)
        print_matrix(f"由 {FINGER_NAME} sensor_2 目标反推得到的 T_ground_tcp", target_ground_tcp)
        print_pose_rpy("Target ground TCP", target_ground_tcp)

        response = call_pinocchio_ik(
            node=node,
            arm_name=arm_name,
            target_ground_tcp=target_ground_tcp,
            arm_max_iterations=options.arm_max_iterations,
            leg_enable=LEG_ENABLE,
            service_timeout_sec=options.service_timeout,
        )
        target_joints = select_response_arm_joints(response, arm_id)
        target_body_tcp = matrix_from_response(response.target_body_tcp_matrix)
        solved_ground_tcp = matrix_from_response(response.solved_ground_tcp_matrix)
        solved_ground_sensor = solved_ground_tcp @ t_tcp_sensor if solved_ground_tcp is not None else None

        print("\n================ Pinocchio 灵巧手 sensor_2 逆解结果 ================")
        print(f"逆解是否成功: {bool(response.success)}")
        print(f"服务状态: {response.message}")
        print(f"逆解关节角(deg): {[round(v, 6) for v in target_joints]}")
        print(f"手臂迭代次数: {int(response.arm_iterations)}")
        print(f"位置误差(m): {float(response.position_error_m):.9g}")
        print(f"姿态误差(rad): {float(response.orientation_error_rad):.9g}")
        print(f"腿部逆解是否启用: {bool(LEG_ENABLE)}")
        print(f"腿部迭代次数: {int(response.leg_iterations)}")
        print(f"腿部逆解关节角(deg): {[round(float(v), 6) for v in response.leg_joints_deg]}")
        print(
            "服务选择的 body 增量: "
            f"dx={float(response.selected_body_dx_m):.6f} m, "
            f"dz={float(response.selected_body_dz_m):.6f} m, "
            f"dpitch={float(response.selected_body_dpitch_deg):.6f} deg, "
            f"dyaw={float(response.selected_body_dyaw_deg):.6f} deg"
        )
        print("腿部运动控制: 本 demo 不下发任何腿部真实运动指令")
        if LEG_ENABLE and execute_motion:
            print("注意: 当前只会下发手臂关节角；若 IK 结果依赖腿部位姿变化，实际 TCP 可能无法到达目标 ground 位姿")
        print_matrix("服务换算后的目标 T_body_tcp", target_body_tcp)
        print_matrix("逆解关节角闭环正解 T_ground_tcp", solved_ground_tcp)
        print_matrix(f"逆解关节角闭环正解 {hand_name} {FINGER_NAME} T_ground_{FINGER_NAME}_sensor_2", solved_ground_sensor)
        print(
            f"{hand_name} {FINGER_NAME} sensor_2 目标矩阵与闭环正解矩阵最大元素误差: "
            f"{matrix_error(target_ground_sensor, solved_ground_sensor):.9g}"
        )

        if not response.success:
            node.get_logger().error(f"Pinocchio IK failed: {response.message}")
            return
        if len(target_joints) != 7:
            raise RuntimeError(f"IK 返回关节角数量不是 7: {len(target_joints)}")

        if not execute_motion:
            node.get_logger().warning("Dry run: 只计算 IK。加入 --execute 才会下发机械臂运动。")
            return

        node.connect_robot()
        log_arm_feedback(node, arm_id, "Before configure")

        clear_response = command(node, node.clear_cli, ArmClearErr, arm_id=arm_id)
        node.get_logger().info(f"Arm {arm_id} clear response: {clear_response.message}")
        vel_response = command(node, node.vel_cli, SetArmVelAcc, arm_id=arm_id, vel=VELOCITY_PERCENT, acc=ACCELERATION_PERCENT)
        node.get_logger().info(f"Arm {arm_id} vel/acc response: {vel_response.message}")
        state_response = command(node, node.state_cli, SetArmState, arm_id=arm_id, state=1)
        node.get_logger().info(f"Arm {arm_id} set state response: {state_response.message}")
        if not options.allow_state_mismatch:
            wait_for_arm_state(node, arm_id, expected_state=1, timeout_sec=STATE_TIMEOUT_SEC)
            node.get_logger().info(f"Arm {arm_id} is in position mode")
        enabled = True

        command_response = command(node, node.position_cli, SetJointCmdPos, arm_id=arm_id, joints=target_joints)
        node.get_logger().info(f"Arm {arm_id} target response: {command_response.message}")
        node.get_logger().info(f"Pinocchio IK target joints sent, wait {WAIT_AFTER_COMMAND_SEC} sec")
        wait_until_arrived(node, arm_id, target_joints, timeout_sec=options.target_timeout)
        time.sleep(WAIT_AFTER_COMMAND_SEC)

    except KeyboardInterrupt:
        node.get_logger().info("Ctrl+C received, exit.")
    finally:
        if enabled and not options.keep_enabled:
            try:
                command(node, node.state_cli, SetArmState, arm_id=arm_id, state=0)
                node.get_logger().info(f"Arm {arm_id} disabled")
            except Exception as exc:  # pylint: disable=broad-except
                node.get_logger().error(f"Disable failed: {exc}")
        elif enabled:
            node.get_logger().info(f"Arm {arm_id} kept enabled")
        finish(node)


if __name__ == "__main__":
    main()

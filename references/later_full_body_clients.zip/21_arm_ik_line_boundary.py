#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JIBOT hand-sensor straight-line IK and X-Z boundary experiments.

The script is intended to run in the robot ROS2 workspace. It plans every point
through ``/ik/full_body_ik`` and records CSV/JSON data. Grid mode never moves the
robot. Line mode is also calculation-only unless ``--execute`` is explicitly set.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import rclpy

from arm_ros2_common import MarvinServiceClient, arm_index, command, finish
from ik_experiment_core import (
    boundary_rows,
    generate_line_waypoints,
    generate_xz_grid,
    inclusive_axis_values,
    pose_error,
    resolve_line_end_xyz,
    transform_with_xyz,
    validate_transform,
)
from marvin_interfaces.msg import RobotFrames
from sensor_msgs.msg import JointState
from marvin_interfaces.srv import (
    ArmClearErr,
    PinocchioFullBodyIK,
    SetArmState,
    SetArmVelAcc,
    SetJointCmdPos,
)


MARVIN_ROBOT_PY_DIR = "/home/user/jibot_ros2_opensource/30_ros_ws/src/drivers/marvin_robot/marvin_robot"
if MARVIN_ROBOT_PY_DIR not in sys.path:
    sys.path.insert(0, MARVIN_ROBOT_PY_DIR)

from jibot_kine import RobotHand  # noqa: E402


ARM_GROUND_FRAMES_TOPIC = "/frame/arm_ground_frames"
FULL_BODY_IK_SERVICE = "/ik/full_body_ik"
BODY_JOINT_STATES_TOPIC = "/joint_states"
CHECK_PERIOD_SEC = 0.2
STATE_TIMEOUT_SEC = 5.0
ZERO_BODY_PUBLISH_PERIOD_SEC = 0.05
ZERO_BODY_JOINT_NAMES = (
    "head_pitch",
    "head_yaw",
    "waist_joint",
    "leg_joint_3",
    "leg_joint_2",
    "leg_joint_1",
)

RESULT_FIELDS = [
    "mode",
    "point_index",
    "x_index",
    "z_index",
    "line_fraction",
    "path_distance_m",
    "target_sensor_x_m",
    "target_sensor_y_m",
    "target_sensor_z_m",
    "target_roll_deg",
    "target_pitch_deg",
    "target_yaw_deg",
    "service_success",
    "success",
    "message",
    "arm_iterations",
    "service_position_error_m",
    "service_orientation_error_rad",
    "sensor_position_error_m",
    "sensor_orientation_error_rad",
    "sensor_matrix_max_error",
    "target_tcp_x_m",
    "target_tcp_y_m",
    "target_tcp_z_m",
    "solved_sensor_x_m",
    "solved_sensor_y_m",
    "solved_sensor_z_m",
    "ik_joints_deg",
    "joint_1_deg",
    "joint_2_deg",
    "joint_3_deg",
    "joint_4_deg",
    "joint_5_deg",
    "joint_6_deg",
    "joint_7_deg",
    "leg_enable",
    "assume_zero_body",
    "leg_iterations",
    "leg_joints_deg",
    "selected_body_dx_m",
    "selected_body_dz_m",
    "selected_body_dpitch_deg",
    "selected_body_dyaw_deg",
]


class IkExperimentClient(MarvinServiceClient):
    """ROS clients and latest ground-frame feedback used by the experiments."""

    def __init__(self, arm_id: str, assume_zero_body: bool = False):
        super().__init__("arm_ik_line_boundary_experiment")
        self.arm_id = arm_id
        self.full_body_ik_cli = self.create_client(PinocchioFullBodyIK, FULL_BODY_IK_SERVICE)
        self.clear_cli = self.create_client(ArmClearErr, "/arm/clear_arm_error")
        self.state_cli = self.create_client(SetArmState, "/arm/set_arm_state")
        self.vel_cli = self.create_client(SetArmVelAcc, "/arm/set_arm_vel_acc")
        self.position_cli = self.create_client(SetJointCmdPos, "/arm/set_joint_cmd_pos")
        self.latest_ground_frames: Optional[RobotFrames] = None
        self.create_subscription(RobotFrames, ARM_GROUND_FRAMES_TOPIC, self._frame_callback, 10)
        self._zero_body_publisher = None
        self._zero_body_timer = None
        self._zero_body_conflict = ""
        if assume_zero_body:
            self._start_zero_body_publisher()

    def _frame_callback(self, message: RobotFrames) -> None:
        self.latest_ground_frames = message

    def _external_body_publishers(self):
        return [
            info
            for info in self.get_publishers_info_by_topic(BODY_JOINT_STATES_TOPIC)
            if not (info.node_name == self.get_name() and info.node_namespace == self.get_namespace())
        ]

    def _start_zero_body_publisher(self) -> None:
        discovery_deadline = time.monotonic() + 0.5
        while time.monotonic() < discovery_deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
        external = self._external_body_publishers()
        if external:
            names = [f"{info.node_namespace}/{info.node_name}" for info in external]
            raise RuntimeError(
                f"refusing --assume-zero-body: {BODY_JOINT_STATES_TOPIC} already has publishers {names}"
            )
        self._zero_body_publisher = self.create_publisher(JointState, BODY_JOINT_STATES_TOPIC, 10)
        self._zero_body_timer = self.create_timer(
            ZERO_BODY_PUBLISH_PERIOD_SEC,
            self._publish_zero_body_joint_state,
        )
        self._publish_zero_body_joint_state()
        self.get_logger().warning(
            "ZERO BODY ASSUMPTION enabled: publishing waist/leg joints as 0 deg; "
            "body actuators are not enabled or commanded"
        )

    def _publish_zero_body_joint_state(self) -> None:
        external = self._external_body_publishers()
        if external:
            names = [f"{info.node_namespace}/{info.node_name}" for info in external]
            self._zero_body_conflict = (
                f"real {BODY_JOINT_STATES_TOPIC} publishers appeared {names}; stopped assumed-zero publishing"
            )
            if self._zero_body_timer is not None:
                self._zero_body_timer.cancel()
            self.get_logger().error(self._zero_body_conflict)
            return
        message = JointState()
        message.header.stamp = self.get_clock().now().to_msg()
        message.name = list(ZERO_BODY_JOINT_NAMES)
        message.position = [0.0] * len(ZERO_BODY_JOINT_NAMES)
        self._zero_body_publisher.publish(message)

    def ensure_zero_body_source_safe(self) -> None:
        if self._zero_body_conflict:
            raise RuntimeError(self._zero_body_conflict)


def arm_name_from_id(arm_id: str) -> str:
    return "L_arm" if arm_id.upper() == "A" else "R_arm"


def hand_name_from_arm_id(arm_id: str) -> str:
    return "L_hand" if arm_id.upper() == "A" else "R_hand"


def flatten_matrix(matrix: np.ndarray) -> list[float]:
    return [float(value) for value in np.asarray(matrix, dtype=float).reshape(-1)]


def matrix_from_response(values) -> np.ndarray | None:
    data = [float(value) for value in values]
    if len(data) != 16:
        return None
    return np.asarray(data, dtype=float).reshape((4, 4))


def matrix_to_rpy_deg(rotation: np.ndarray) -> tuple[float, float, float]:
    """Convert Rz(yaw) @ Ry(pitch) @ Rx(roll) to degrees."""
    sy = math.hypot(rotation[0, 0], rotation[1, 0])
    if sy >= 1e-9:
        roll = math.atan2(rotation[2, 1], rotation[2, 2])
        pitch = math.atan2(-rotation[2, 0], sy)
        yaw = math.atan2(rotation[1, 0], rotation[0, 0])
    else:
        roll = math.atan2(-rotation[1, 2], rotation[1, 1])
        pitch = math.atan2(-rotation[2, 0], sy)
        yaw = 0.0
    return tuple(math.degrees(value) for value in (roll, pitch, yaw))


def get_tcp_sensor_transform(hand: RobotHand, finger_name: str, hand_command: int) -> np.ndarray:
    if finger_name not in RobotHand.FINGER_NAMES:
        raise ValueError(f"finger must be one of {list(RobotHand.FINGER_NAMES)}, got {finger_name!r}")
    return RobotHand.get_tcp_hand_base_transform() @ hand.get_hand_base_sensor_transform(
        finger_name,
        hand_commands=hand_command,
    )


def sensor_target_to_tcp_target(target_ground_sensor: np.ndarray, t_tcp_sensor: np.ndarray) -> np.ndarray:
    return target_ground_sensor @ np.linalg.inv(t_tcp_sensor)


def read_current_ground_frame(
    node: IkExperimentClient,
    timeout_sec: float,
) -> tuple[np.ndarray, list[float]]:
    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.1)
        node.ensure_zero_body_source_safe()
        message = node.latest_ground_frames
        if message is None or not message.success:
            continue
        if node.arm_id == "A":
            matrix_data = message.ground_left_tcp
            joints = message.left_arm_joints_deg
        else:
            matrix_data = message.ground_right_tcp
            joints = message.right_arm_joints_deg
        if len(matrix_data) != 16:
            continue
        matrix = validate_transform(np.asarray(matrix_data, dtype=float).reshape((4, 4)), "current_ground_tcp", atol=1e-3)
        return matrix, [float(value) for value in joints]
    raise RuntimeError(f"no valid {ARM_GROUND_FRAMES_TOPIC} feedback within {timeout_sec:.1f}s")


def wait_for_ik_service(node: IkExperimentClient, timeout_sec: float) -> None:
    deadline = time.monotonic() + timeout_sec
    while not node.full_body_ik_cli.wait_for_service(timeout_sec=1.0):
        if time.monotonic() >= deadline:
            raise RuntimeError(
                f"{FULL_BODY_IK_SERVICE} is unavailable; start: "
                "ros2 run marvin_robot pinocchio_ik_service_node"
            )
        node.get_logger().info(f"Waiting for {FULL_BODY_IK_SERVICE} ...")


def call_ik(
    node: IkExperimentClient,
    arm_name: str,
    target_ground_tcp: np.ndarray,
    arm_max_iterations: int,
    leg_enable: bool,
) -> PinocchioFullBodyIK.Response:
    node.ensure_zero_body_source_safe()
    request = PinocchioFullBodyIK.Request()
    request.tcp_name = arm_name
    request.target_ground_matrix = flatten_matrix(target_ground_tcp)
    request.leg_enable = bool(leg_enable)
    request.normalize_rotation = False
    request.arm_max_iterations = int(arm_max_iterations)
    request.leg_max_iterations = 0
    future = node.full_body_ik_cli.call_async(request)
    rclpy.spin_until_future_complete(node, future)
    if future.exception() is not None:
        raise RuntimeError(f"{FULL_BODY_IK_SERVICE} raised: {future.exception()}")
    response = future.result()
    if response is None:
        raise RuntimeError(f"{FULL_BODY_IK_SERVICE} returned no response")
    node.ensure_zero_body_source_safe()
    return response


def selected_arm_joints(response: PinocchioFullBodyIK.Response, arm_id: str) -> list[float]:
    values = response.left_arm_joints_deg if arm_id == "A" else response.right_arm_joints_deg
    return [float(value) for value in values]


def result_from_response(
    *,
    mode: str,
    point_index: int,
    x_index: int | None,
    z_index: int | None,
    line_fraction: float | None,
    path_distance_m: float | None,
    target_sensor: np.ndarray,
    target_tcp: np.ndarray,
    t_tcp_sensor: np.ndarray,
    response: PinocchioFullBodyIK.Response,
    arm_id: str,
    leg_enable: bool,
    assume_zero_body: bool,
    position_tolerance_m: float,
    orientation_tolerance_rad: float,
) -> tuple[dict, list[float]]:
    joints = selected_arm_joints(response, arm_id)
    solved_tcp = matrix_from_response(response.solved_ground_tcp_matrix)
    solved_sensor = solved_tcp @ t_tcp_sensor if solved_tcp is not None else None
    try:
        sensor_position_error, sensor_orientation_error, sensor_matrix_error = pose_error(target_sensor, solved_sensor)
    except ValueError:
        sensor_position_error = sensor_orientation_error = sensor_matrix_error = float("inf")
    service_success = bool(response.success)
    validation_success = (
        service_success
        and sensor_position_error <= position_tolerance_m
        and sensor_orientation_error <= orientation_tolerance_rad
        and len(joints) == 7
    )
    roll_deg, pitch_deg, yaw_deg = matrix_to_rpy_deg(target_sensor[:3, :3])
    solved_position = solved_sensor[:3, 3] if solved_sensor is not None else [None, None, None]
    joint_columns = (joints + [None] * 7)[:7]
    row = {
        "mode": mode,
        "point_index": point_index,
        "x_index": x_index,
        "z_index": z_index,
        "line_fraction": line_fraction,
        "path_distance_m": path_distance_m,
        "target_sensor_x_m": float(target_sensor[0, 3]),
        "target_sensor_y_m": float(target_sensor[1, 3]),
        "target_sensor_z_m": float(target_sensor[2, 3]),
        "target_roll_deg": roll_deg,
        "target_pitch_deg": pitch_deg,
        "target_yaw_deg": yaw_deg,
        "service_success": service_success,
        "success": validation_success,
        "message": str(response.message),
        "arm_iterations": int(response.arm_iterations),
        "service_position_error_m": float(response.position_error_m),
        "service_orientation_error_rad": float(response.orientation_error_rad),
        "sensor_position_error_m": sensor_position_error,
        "sensor_orientation_error_rad": sensor_orientation_error,
        "sensor_matrix_max_error": sensor_matrix_error,
        "target_tcp_x_m": float(target_tcp[0, 3]),
        "target_tcp_y_m": float(target_tcp[1, 3]),
        "target_tcp_z_m": float(target_tcp[2, 3]),
        "solved_sensor_x_m": solved_position[0],
        "solved_sensor_y_m": solved_position[1],
        "solved_sensor_z_m": solved_position[2],
        "ik_joints_deg": json.dumps(joints, ensure_ascii=False),
        **{f"joint_{index + 1}_deg": joint_columns[index] for index in range(7)},
        "leg_enable": bool(leg_enable),
        "assume_zero_body": bool(assume_zero_body),
        "leg_iterations": int(response.leg_iterations),
        "leg_joints_deg": json.dumps([float(value) for value in response.leg_joints_deg]),
        "selected_body_dx_m": float(response.selected_body_dx_m),
        "selected_body_dz_m": float(response.selected_body_dz_m),
        "selected_body_dpitch_deg": float(response.selected_body_dpitch_deg),
        "selected_body_dyaw_deg": float(response.selected_body_dyaw_deg),
    }
    return row, joints


class CsvRecorder:
    """Write each completed point immediately so an interrupted scan is usable."""

    def __init__(self, path: Path):
        self.path = path
        self.handle = path.open("w", newline="", encoding="utf-8-sig")
        self.writer = csv.DictWriter(self.handle, fieldnames=RESULT_FIELDS, extrasaction="ignore")
        self.writer.writeheader()

    def append(self, row: dict) -> None:
        self.writer.writerow(row)
        self.handle.flush()

    def close(self) -> None:
        self.handle.close()


def dump_json(path: Path, value: dict) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)


def json_matrix(matrix: np.ndarray) -> list[list[float]]:
    return [[float(value) for value in row] for row in matrix]


def progress_log(node: IkExperimentClient, completed: int, total: int, row: dict) -> None:
    node.get_logger().info(
        f"[{completed}/{total}] xyz=({row['target_sensor_x_m']:.4f}, "
        f"{row['target_sensor_y_m']:.4f}, {row['target_sensor_z_m']:.4f}) "
        f"service={row['service_success']} validated={row['success']} "
        f"iter={row['arm_iterations']} pos_err={row['sensor_position_error_m']:.3g}m"
    )


def run_line(
    node: IkExperimentClient,
    args,
    current_sensor: np.ndarray,
    current_joints: list[float],
    t_tcp_sensor: np.ndarray,
    output_dir: Path,
) -> dict:
    start_sensor = current_sensor.copy()
    if args.start_xyz is not None:
        start_sensor = transform_with_xyz(start_sensor, args.start_xyz)
    if args.orientation_mat3x3 is not None:
        start_sensor[:3, :3] = np.asarray(args.orientation_mat3x3, dtype=float).reshape((3, 3))
        start_sensor = validate_transform(start_sensor, "line start target", atol=1e-4)

    waypoints = generate_line_waypoints(
        start_sensor,
        resolve_line_end_xyz(start_sensor, end_xyz=args.end_xyz, delta_xyz=args.delta_xyz),
        requested_steps=args.steps,
        max_step_m=args.max_step_m,
    )
    line_length = float(np.linalg.norm(waypoints[-1][:3, 3] - waypoints[0][:3, 3]))
    recorder = CsvRecorder(output_dir / "line_results.csv")
    rows: list[dict] = []
    solutions: list[list[float]] = []
    try:
        for offset, target_sensor in enumerate(waypoints):
            fraction = offset / (len(waypoints) - 1)
            target_tcp = sensor_target_to_tcp_target(target_sensor, t_tcp_sensor)
            response = call_ik(
                node,
                arm_name_from_id(args.arm),
                target_tcp,
                args.arm_max_iterations,
                args.leg_enable,
            )
            row, joints = result_from_response(
                mode="line",
                point_index=offset + 1,
                x_index=None,
                z_index=None,
                line_fraction=fraction,
                path_distance_m=fraction * line_length,
                target_sensor=target_sensor,
                target_tcp=target_tcp,
                t_tcp_sensor=t_tcp_sensor,
                response=response,
                arm_id=args.arm,
                leg_enable=args.leg_enable,
                assume_zero_body=args.assume_zero_body,
                position_tolerance_m=args.position_tolerance_m,
                orientation_tolerance_rad=args.orientation_tolerance_rad,
            )
            recorder.append(row)
            rows.append(row)
            solutions.append(joints)
            progress_log(node, offset + 1, len(waypoints), row)
    finally:
        recorder.close()

    if args.execute:
        execute_line(node, args, current_joints, rows, solutions)

    return {
        "mode": "line",
        "line_length_m": line_length,
        "planned_points": len(waypoints),
        "completed_points": len(rows),
        "successful_points": sum(bool(row["success"]) for row in rows),
        "start_sensor_matrix": json_matrix(start_sensor),
        "end_sensor_matrix": json_matrix(waypoints[-1]),
        "executed": bool(args.execute),
    }


def run_grid(
    node: IkExperimentClient,
    args,
    current_sensor: np.ndarray,
    t_tcp_sensor: np.ndarray,
    output_dir: Path,
) -> dict:
    center = current_sensor.copy()
    if args.center_xyz is not None:
        center = transform_with_xyz(center, args.center_xyz)
    if args.orientation_mat3x3 is not None:
        center[:3, :3] = np.asarray(args.orientation_mat3x3, dtype=float).reshape((3, 3))
        center = validate_transform(center, "grid center target", atol=1e-4)

    if args.x_range is None:
        x_min = float(center[0, 3] + args.x_offset_range[0])
        x_max = float(center[0, 3] + args.x_offset_range[1])
    else:
        x_min, x_max = args.x_range
    if args.z_range is None:
        z_min = float(center[2, 3] + args.z_offset_range[0])
        z_max = float(center[2, 3] + args.z_offset_range[1])
    else:
        z_min, z_max = args.z_range
    x_values = inclusive_axis_values(x_min, x_max, args.step_m)
    z_values = inclusive_axis_values(z_min, z_max, args.step_m)
    waypoints = list(generate_xz_grid(center, x_values, z_values, snake=not args.no_snake))

    recorder = CsvRecorder(output_dir / "grid_results.csv")
    rows: list[dict] = []
    try:
        for waypoint in waypoints:
            target_sensor = waypoint.target_matrix
            target_tcp = sensor_target_to_tcp_target(target_sensor, t_tcp_sensor)
            response = call_ik(
                node,
                arm_name_from_id(args.arm),
                target_tcp,
                args.arm_max_iterations,
                args.leg_enable,
            )
            row, _ = result_from_response(
                mode="grid",
                point_index=waypoint.point_index,
                x_index=waypoint.x_index,
                z_index=waypoint.z_index,
                line_fraction=None,
                path_distance_m=None,
                target_sensor=target_sensor,
                target_tcp=target_tcp,
                t_tcp_sensor=t_tcp_sensor,
                response=response,
                arm_id=args.arm,
                leg_enable=args.leg_enable,
                assume_zero_body=args.assume_zero_body,
                position_tolerance_m=args.position_tolerance_m,
                orientation_tolerance_rad=args.orientation_tolerance_rad,
            )
            recorder.append(row)
            rows.append(row)
            progress_log(node, len(rows), len(waypoints), row)
    finally:
        recorder.close()

    summary = boundary_rows(rows)
    summary_path = output_dir / "boundary_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8-sig") as handle:
        fields = ["target_sensor_x_m", "success_count", "min_success_z_m", "max_success_z_m", "has_internal_gap"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary)

    return {
        "mode": "grid",
        "planned_points": len(waypoints),
        "completed_points": len(rows),
        "successful_points": sum(bool(row["success"]) for row in rows),
        "x_range_m": [x_min, x_max],
        "z_range_m": [z_min, z_max],
        "fixed_y_m": float(center[1, 3]),
        "step_m": float(args.step_m),
        "x_count": len(x_values),
        "z_count": len(z_values),
        "center_sensor_matrix": json_matrix(center),
        "boundary_x_count": len(summary),
        "executed": False,
    }


def read_arm_feedback(node: IkExperimentClient, arm_id: str) -> dict:
    data = node.robot_data()
    index = arm_index(arm_id)
    if len(data.outputs) <= index or len(data.states) <= index or len(data.inputs) <= index:
        raise RuntimeError(f"robot_data does not contain arm {arm_id}")
    state = data.states[index]
    return {
        "state": int(state.cur_state),
        "cmd_state": int(state.cmd_state),
        "err_code": int(state.err_code),
        "joints": [float(value) for value in data.outputs[index].fb_joint_pos],
    }


def wait_for_arm_state(node: IkExperimentClient, arm_id: str, expected_state: int, timeout_sec: float) -> None:
    deadline = time.monotonic() + timeout_sec
    last = None
    while time.monotonic() <= deadline:
        rclpy.spin_once(node, timeout_sec=0.0)
        node.ensure_zero_body_source_safe()
        last = read_arm_feedback(node, arm_id)
        if last["err_code"]:
            raise RuntimeError(f"arm {arm_id} error {last['err_code']} while waiting for state {expected_state}")
        if last["state"] == expected_state:
            return
        time.sleep(CHECK_PERIOD_SEC)
    raise RuntimeError(f"arm {arm_id} did not enter state {expected_state}; last={last}")


def wait_until_arrived(
    node: IkExperimentClient,
    arm_id: str,
    target_joints: list[float],
    tolerance_deg: float,
    timeout_sec: float,
) -> None:
    deadline = time.monotonic() + timeout_sec
    while time.monotonic() <= deadline:
        rclpy.spin_once(node, timeout_sec=0.0)
        node.ensure_zero_body_source_safe()
        feedback = read_arm_feedback(node, arm_id)
        if feedback["err_code"]:
            raise RuntimeError(f"arm {arm_id} error {feedback['err_code']} while moving")
        if feedback["state"] != 1:
            raise RuntimeError(f"arm {arm_id} left position mode while moving: {feedback}")
        error = max(abs(actual - target) for actual, target in zip(feedback["joints"], target_joints))
        if error <= tolerance_deg:
            return
        time.sleep(CHECK_PERIOD_SEC)
    raise RuntimeError(f"arm {arm_id} did not reach waypoint within {timeout_sec:.1f}s")


def execute_line(
    node: IkExperimentClient,
    args,
    current_joints: list[float],
    rows: list[dict],
    solutions: list[list[float]],
) -> None:
    node.ensure_zero_body_source_safe()
    if args.leg_enable:
        raise RuntimeError("refusing --execute because --leg-enable may require uncommanded leg/body motion")
    failed = [row["point_index"] for row in rows if not row["success"]]
    if failed:
        raise RuntimeError(f"refusing --execute because validated IK failed at points {failed[:20]}")
    if len(current_joints) != 7 or any(len(solution) != 7 for solution in solutions):
        raise RuntimeError("refusing --execute because current/target joint vectors are not all length 7")

    previous = current_joints
    for index, solution in enumerate(solutions, start=1):
        delta = max(abs(target - source) for source, target in zip(previous, solution))
        if delta > args.max_joint_step_deg:
            raise RuntimeError(
                f"refusing --execute: point {index} changes one joint by {delta:.3f} deg "
                f"(limit {args.max_joint_step_deg:.3f} deg)"
            )
        previous = solution

    enabled = False
    try:
        node.connect_robot()
        command(node, node.clear_cli, ArmClearErr, arm_id=args.arm)
        command(
            node,
            node.vel_cli,
            SetArmVelAcc,
            arm_id=args.arm,
            vel=args.velocity_percent,
            acc=args.acceleration_percent,
        )
        command(node, node.state_cli, SetArmState, arm_id=args.arm, state=1)
        enabled = True
        wait_for_arm_state(node, args.arm, expected_state=1, timeout_sec=STATE_TIMEOUT_SEC)
        for index, target_joints in enumerate(solutions, start=1):
            node.ensure_zero_body_source_safe()
            command(node, node.position_cli, SetJointCmdPos, arm_id=args.arm, joints=target_joints)
            wait_until_arrived(
                node,
                args.arm,
                target_joints,
                tolerance_deg=args.arrive_tolerance_deg,
                timeout_sec=args.waypoint_timeout_sec,
            )
            node.get_logger().info(f"Executed line waypoint {index}/{len(solutions)}")
            if args.dwell_sec > 0:
                time.sleep(args.dwell_sec)
    finally:
        if enabled and not args.keep_enabled:
            command(node, node.state_cli, SetArmState, arm_id=args.arm, state=0)
            node.get_logger().info(f"Arm {args.arm} disabled after line execution")


def add_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--arm", default="A", choices=["A", "B", "a", "b"], help="A=left arm, B=right arm")
    parser.add_argument("--finger", default="index", choices=["thumb", "index", "middle", "ring", "little"])
    parser.add_argument("--hand-command", type=int, default=1000, help="finger FK command, 0-1000")
    parser.add_argument("--leg-enable", action="store_true", help="allow leg/body participation in calculation only")
    parser.add_argument(
        "--assume-zero-body",
        action="store_true",
        help="publish fixed zero waist/leg state for calculation when /joint_states has no publisher",
    )
    parser.add_argument("--arm-max-iterations", type=int, default=0, help="0 uses service configuration")
    parser.add_argument("--service-timeout", type=float, default=10.0)
    parser.add_argument("--frame-timeout", type=float, default=5.0)
    parser.add_argument("--position-tolerance-m", type=float, default=1e-4)
    parser.add_argument("--orientation-tolerance-rad", type=float, default=1e-3)
    parser.add_argument("--output-dir", help="default: ik_results/<timestamp>_<mode>")
    parser.add_argument(
        "--orientation-mat3x3",
        type=float,
        nargs=9,
        help="optional fixed sensor orientation in row-major order; default is current sensor orientation",
    )


def parse_args():
    parser = argparse.ArgumentParser(description="JIBOT arm straight-line IK and boundary scan")
    subparsers = parser.add_subparsers(dest="mode", required=True)

    line = subparsers.add_parser("line", help="plan a straight Cartesian sensor path; optionally execute it")
    add_common_arguments(line)
    line.add_argument("--start-xyz", type=float, nargs=3, help="ground XYZ in m; default is current sensor position")
    line_target = line.add_mutually_exclusive_group(required=True)
    line_target.add_argument("--end-xyz", type=float, nargs=3, help="absolute ground endpoint XYZ in m")
    line_target.add_argument(
        "--delta-xyz",
        type=float,
        nargs=3,
        help="endpoint offset from the selected start XYZ in ground coordinates, in m",
    )
    line.add_argument("--steps", type=int, default=0, help="waypoint count; 0 chooses from --max-step-m")
    line.add_argument("--max-step-m", type=float, default=0.01, help="maximum Cartesian gap between waypoints")
    line.add_argument("--execute", action="store_true", help="move only after every waypoint passes IK and safety checks")
    line.add_argument(
        "--confirm-zero-body-execute",
        action="store_true",
        help="confirm physical waist/leg are fixed at zero before executing with --assume-zero-body",
    )
    line.add_argument("--max-joint-step-deg", type=float, default=10.0)
    line.add_argument("--velocity-percent", type=int, default=5)
    line.add_argument("--acceleration-percent", type=int, default=5)
    line.add_argument("--arrive-tolerance-deg", type=float, default=1.0)
    line.add_argument("--waypoint-timeout-sec", type=float, default=20.0)
    line.add_argument("--dwell-sec", type=float, default=0.05)
    line.add_argument("--keep-enabled", action="store_true")

    grid = subparsers.add_parser("grid", help="calculation-only X-Z workspace scan at fixed Y/orientation")
    add_common_arguments(grid)
    grid.add_argument("--center-xyz", type=float, nargs=3, help="default is current sensor position")
    grid.add_argument("--x-range", type=float, nargs=2, metavar=("MIN", "MAX"), help="absolute ground X range in m")
    grid.add_argument("--z-range", type=float, nargs=2, metavar=("MIN", "MAX"), help="absolute ground Z range in m")
    grid.add_argument("--x-offset-range", type=float, nargs=2, default=[-0.05, 0.05], metavar=("MIN", "MAX"))
    grid.add_argument("--z-offset-range", type=float, nargs=2, default=[-0.05, 0.05], metavar=("MIN", "MAX"))
    grid.add_argument("--step-m", type=float, default=0.01)
    grid.add_argument("--no-snake", action="store_true", help="scan every X column from low Z to high Z")

    return parser.parse_known_args()


def main() -> None:
    options, ros_args = parse_args()
    options.arm = options.arm.upper()
    if not 0 <= options.hand_command <= 1000:
        raise ValueError("--hand-command must be between 0 and 1000")
    if options.position_tolerance_m <= 0 or options.orientation_tolerance_rad <= 0:
        raise ValueError("IK validation tolerances must be positive")
    if options.assume_zero_body and options.leg_enable:
        raise ValueError("--assume-zero-body cannot be combined with --leg-enable")
    if options.mode == "line":
        if options.confirm_zero_body_execute and not options.assume_zero_body:
            raise ValueError("--confirm-zero-body-execute requires --assume-zero-body")
        if options.execute and options.assume_zero_body and not options.confirm_zero_body_execute:
            raise RuntimeError(
                "refusing execution with --assume-zero-body unless --confirm-zero-body-execute is also set"
            )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(options.output_dir or f"ik_results/{timestamp}_{options.mode}").resolve()
    output_dir.mkdir(parents=True, exist_ok=False)

    rclpy.init(args=[sys.argv[0], *ros_args])
    node = IkExperimentClient(options.arm, assume_zero_body=options.assume_zero_body)
    metadata = {
        "schema_version": 1,
        "created_at_local": datetime.now().astimezone().isoformat(),
        "status": "started",
        "mode": options.mode,
        "arguments": vars(options),
        "output_directory": str(output_dir),
        "success_definition": {
            "service_success_required": True,
            "sensor_position_error_max_m": options.position_tolerance_m,
            "sensor_orientation_error_max_rad": options.orientation_tolerance_rad,
            "arm_joint_count": 7,
        },
    }
    dump_json(output_dir / "metadata.json", metadata)

    try:
        hand_name = hand_name_from_arm_id(options.arm)
        hand = RobotHand(hand_name)
        t_tcp_sensor = validate_transform(
            get_tcp_sensor_transform(hand, options.finger, options.hand_command),
            "t_tcp_sensor",
            atol=1e-3,
        )
        current_tcp, current_joints = read_current_ground_frame(node, options.frame_timeout)
        current_sensor = validate_transform(current_tcp @ t_tcp_sensor, "current_ground_sensor", atol=1e-3)
        wait_for_ik_service(node, options.service_timeout)

        metadata.update(
            {
                "arm_name": arm_name_from_id(options.arm),
                "hand_name": hand_name,
                "finger": options.finger,
                "hand_command": options.hand_command,
                "body_state_source": "assumed_zero" if options.assume_zero_body else BODY_JOINT_STATES_TOPIC,
                "assumed_zero_body_joint_names": list(ZERO_BODY_JOINT_NAMES) if options.assume_zero_body else [],
                "current_arm_joints_deg": current_joints,
                "current_ground_tcp_matrix": json_matrix(current_tcp),
                "t_tcp_sensor_matrix": json_matrix(t_tcp_sensor),
                "current_ground_sensor_matrix": json_matrix(current_sensor),
            }
        )
        dump_json(output_dir / "metadata.json", metadata)

        if options.mode == "line":
            summary = run_line(node, options, current_sensor, current_joints, t_tcp_sensor, output_dir)
        else:
            summary = run_grid(node, options, current_sensor, t_tcp_sensor, output_dir)
        metadata.update({"status": "completed", "summary": summary})
        dump_json(output_dir / "metadata.json", metadata)
        node.get_logger().info(f"Experiment completed. Results: {output_dir}")
    except KeyboardInterrupt:
        metadata["status"] = "interrupted"
        dump_json(output_dir / "metadata.json", metadata)
        node.get_logger().warning(f"Interrupted. Completed CSV rows remain in {output_dir}")
    except Exception as exc:
        metadata.update({"status": "failed", "error": str(exc)})
        dump_json(output_dir / "metadata.json", metadata)
        raise
    finally:
        finish(node)


if __name__ == "__main__":
    main()
